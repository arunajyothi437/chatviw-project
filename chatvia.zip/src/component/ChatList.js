import React from "react";
import { FaCircle, FaImage, FaSearch } from "react-icons/fa";

function ChatList() {
  const active = [
    {
      name: "Patrick Hendricks",
      message: "hey! there I’m available",
      time: "02:50 PM",
      img: "https://picsum.photos/50/50?random=1",
      online: true,
    },
    {
      name: "Mark Messer",
      message: "Images",
      time: "10:30 AM",
      img: "https://picsum.photos/50/50?random=2",
      unread: 2,
      online: true,
    },
    {
      name: "General",
      message: "This theme is Awesome!",
      time: "2:06 min",
      img: "https://picsum.photos/50/50?random=3",
      online: true,
    },
    {
      name: "Doris Brown",
      message: "typing...",
      time: "10:05 PM",
      img: "https://picsum.photos/50/50?random=4",
      online: true,
    },
  ];
  const chats = [
    {
      name: "Patrick Hendricks",
      message: "hey! there I’m available",
      time: "02:50 PM",
      img: "https://picsum.photos/50/50?random=1",
      online: true,
    },
    {
      name: "Mark Messer",
      message: "Images",
      time: "10:30 AM",
      img: "https://picsum.photos/50/50?random=2",
      unread: 2,
      online: false,
    },
    {
      name: "General",
      message: "This theme is Awesome!",
      time: "2:06 min",
      img: "https://picsum.photos/50/50?random=3",
      online: false,
    },
    {
      name: "Doris Brown",
      message: "typing...",
      time: "10:05 PM",
      img: "https://picsum.photos/50/50?random=4",
      online: true,
    },
    {
      name: "Designer",
      message: "Next meeting tomorrow 10:00 AM",
      time: "2:10 min",
      img: "https://picsum.photos/50/50?random=5",
      unread: 1,
      online: false,
    },
    {
      name: "Patrick Hendricks",
      message: "hey! there I’m available",
      time: "02:50 PM",
      img: "https://picsum.photos/50/50?random=1",
      online: true,
    },
    {
      name: "Mark Messer",
      message: "Images",
      time: "10:30 AM",
      img: "https://picsum.photos/50/50?random=2",
      unread: 2,
      online: false,
    },
    {
      name: "General",
      message: "This theme is Awesome!",
      time: "2:06 min",
      img: "https://picsum.photos/50/50?random=3",
      online: false,
    },
    {
      name: "Doris Brown",
      message: "typing...",
      time: "10:05 PM",
      img: "https://picsum.photos/50/50?random=4",
      online: true,
    },
    {
      name: "Designer",
      message: "Next meeting tomorrow 10:00 AM",
      time: "2:10 min",
      img: "https://picsum.photos/50/50?random=5",
      unread: 1,
      online: false,
    },
  ];

  return (
    <div className="bg-[#f5f7fb] w-[400px] h-screen border-r p-4 pb-10">
      <h2 className="text-xl font-semibold mb-4">Chats</h2>

      {/* Search Bar */}
      <div className="mb-4">
        <div className="relative">
          <FaSearch className="absolute top-1/2 left-3 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search messages or users"
            className="w-full pl-10 pr-4 py-2 rounded-lg bg-[#e6ebf5] text-gray-600"
          />
        </div>
      </div>

      {/* User Profiles */}
      <div className="flex  justify-around space-x-4 mb-6 px-4 ">
        {active.slice(0, 4).map((chat, index) => (
          <div key={index} className="relative text-center p-2 rounded-md">
            <div
              className="absolute inset-0 bg-[#e6ebf5] rounded-md"
              style={{ height: "50%", bottom: 0, top: "40%" }}
            />
            <div className="relative z-10">
              <div className="relative inline-block">
                <img
                  src={chat.img}
                  alt={chat.name}
                  className="w-10 h-10 rounded-full border-2 border-white shadow-md"
                />
                <div className="absolute bottom-1 right-1 w-3 h-3 rounded-full bg-white flex items-center justify-center border border-white">
                  <FaCircle
                    className={`text-${
                      chat.online ? "green" : "gray"
                    }-500 text-[8px]`}
                  />
                </div>
              </div>
              <p className="text-sm font-medium text-gray-700 -mt-2 pb-2">
                {chat.name.split(" ")[0]}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div
        style={{ maxHeight: "calc(100vh - 220px)" }}
        className="flex flex-col gap-2 scrollable "
      >
        {/* Recent Chats Title */}
        <h3 className="text-gray-500 text-sm font-medium mb-2">Recent</h3>

        {/* Recent Chats List */}
        <ul className="overflow-y-auto pb-5">
          {chats.map((chat, index) => (
            <li
              key={index}
              className="flex items-center py-4  hover:bg-gray-200 rounded-lg px-2 pr-4 "
            >
              <div className="relative mr-3">
                <img
                  src={chat.img}
                  alt={chat.name}
                  className="w-10 h-10 rounded-full"
                />
                <div className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-white flex items-center justify-center">
                  <FaCircle
                    className={`text-${
                      chat.online ? "green" : "gray"
                    }-500 text-xs`}
                  />
                </div>
              </div>
              <div className="flex-grow">
                <h4 className="text-gray-800 font-medium">{chat.name}</h4>
                <p className="text-gray-500 text-sm flex items-center">
                  {chat.message.toLowerCase() === "images" && (
                    <FaImage className="mr-1" />
                  )}
                  {chat.message}
                </p>
              </div>
              <div className="text-right">
                <div className="text-gray-500 text-xs">{chat.time}</div>
                {chat.unread && (
                  <span className="inline-block mt-1 text-xs bg-purple-500 text-white px-2 py-0.5 rounded-full">
                    {chat.unread}
                  </span>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default ChatList;
